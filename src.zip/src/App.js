import React from 'react';
import logo from './logo.svg';
import './App.css';
import 'antd/dist/antd.css';
import { Icon } from 'antd';
import { Layout, Menu, Breadcrumb } from 'antd';
import { Upload, message, Button } from 'antd';
import { Input, Form} from 'antd';
import { Row, Col } from 'antd';


const { Header, Content, Footer } = Layout;

const props = {
  name: 'file',
  action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
  headers: {
    authorization: 'authorization-text',
  },
  onChange(info) {
    if (info.file.status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (info.file.status === 'done') {
      message.success(`${info.file.name} file uploaded successfully`);
    } else if (info.file.status === 'error') {
      message.error(`${info.file.name} file upload failed.`);
    }
  },
};

function App() {
  return (
  <Layout className="layout">
      <Header>
        <div className="logo" />
        <Menu
          theme="dark"
          mode="horizontal"
          defaultSelectedKeys={['2']}
          style={{ lineHeight: '64px' }}
        >
          <Menu.Item key="1">Generator</Menu.Item>
          <Menu.Item key="2">About</Menu.Item>
          <Menu.Item key="3">Other</Menu.Item>
        </Menu>
      </Header>
      <Content style={{ padding: '0 50px' }}>

   
        <div className="site-layout-content">
        <h1>Super Syllabus Generator</h1>
        <h2>Simply upload your syllabi in pdf format and enter in class details.</h2>
          <form id = "pdfs"action="/action_page.php">
          <Form.Item label="Fall/Spring">
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="4"/>
                </div>
              </Form.Item>
          <Form.Item label="Year(ie 2020)">
                <div className="example-input">
                  <Input size="small" placeholder="XXXX" maxLength ="4"/>
                </div>
              </Form.Item>



          <div>
            <Row gutter>
              <Col span={8}>
              <Form.Item label="Subject">
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="4"/>
                </div>
              </Form.Item>

              <Form.Item label="Course Number">
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="3"/>
                </div>
               </Form.Item>

              <Form.Item label="Section Number">      
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="3"/>
                </div>
              </Form.Item>

              <Form.Item label="Syllabus.pdf">   
                <Upload {...props}>
                  <Button>
                    <Icon type="upload" /> Click to Upload
                  </Button>
                </Upload>  
              </Form.Item>
                 <br /><br />
              </Col>
              
                            <Col span={8}>
              <Form.Item label="Subject">
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="4"/>
                </div>
              </Form.Item>

              <Form.Item label="Course Number">
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="3"/>
                </div>
               </Form.Item>

              <Form.Item label="Section Number">      
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="3"/>
                </div>
              </Form.Item>

              <Form.Item label="Syllabus.pdf">   
                <Upload {...props}>
                  <Button>
                    <Icon type="upload" /> Click to Upload
                  </Button>
                </Upload>  
              </Form.Item>
               <br /><br />
              </Col>
                            <Col span={8}>
              <Form.Item label="Subject">
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="4"/>
                </div>
              </Form.Item>

              <Form.Item label="Course Number">
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="3"/>
                </div>
               </Form.Item>

              <Form.Item label="Section Number">      
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="3"/>
                </div>
              </Form.Item>

              <Form.Item label="Syllabus.pdf">   
                <Upload {...props}>
                  <Button>
                    <Icon type="upload" /> Click to Upload
                  </Button>
                </Upload>  
              </Form.Item>
               <br /><br />
              </Col>
            </Row>
            <Row>
                                        <Col span={8}>
              <Form.Item label="Subject">
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="4"/>
                </div>
              </Form.Item>

              <Form.Item label="Course Number">
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="3"/>
                </div>
               </Form.Item>

              <Form.Item label="Section Number">      
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="3"/>
                </div>
              </Form.Item>

              <Form.Item label="Syllabus.pdf">   
                <Upload {...props}>
                  <Button>
                    <Icon type="upload" /> Click to Upload
                  </Button>
                </Upload>  
              </Form.Item>
              </Col>
                      <Col span={8}>
              <Form.Item label="Subject">
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="4"/>
                </div>
              </Form.Item>

              <Form.Item label="Course Number">
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="3"/>
                </div>
               </Form.Item>

              <Form.Item label="Section Number">      
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="3"/>
                </div>
              </Form.Item>

              <Form.Item label="Syllabus.pdf">   
                <Upload {...props}>
                  <Button>
                    <Icon type="upload" /> Click to Upload
                  </Button>
                </Upload>  
              </Form.Item>
              </Col>
                                         <Col span={8}>
              <Form.Item label="Subject">
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="4"/>
                </div>
              </Form.Item>

              <Form.Item label="Course Number">
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="3"/>
                </div>
               </Form.Item>

              <Form.Item label="Section Number">      
                <div className="example-input">
                  <Input size="small" placeholder="" maxLength ="3"/>
                </div>
              </Form.Item>

              <Form.Item label="Syllabus.pdf">   
                <Upload {...props}>
                  <Button>
                    <Icon type="upload" /> Click to Upload
                  </Button>
                </Upload>  
              </Form.Item>
              </Col>
            </Row>
          
          </div>
              <Form.Item wrapperCol={{ span: 12, offset: 6 }}>
              <Button type="primary" htmlType="submit">Submit</Button>
            </Form.Item>
          </form>
        </div>


      </Content>
      <Footer style={{ textAlign: 'center' }}>Ant Design ©2018 Created by Ant UED</Footer>
    </Layout>
  );
}

export default App;
